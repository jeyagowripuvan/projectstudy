package com.example.studentmicroservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.studentmicroservice.model.Student;
import com.example.studentmicroservice.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	RestTemplate restTemplate;

	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}
	
	@Autowired
	StudentService studentService;
	
	@PostMapping("/savestudent")
	public ResponseEntity<?> saveStudent(@RequestBody Student student){
		return new ResponseEntity<>(studentService.addStudent(student),HttpStatus.OK);
	}
	
	@PutMapping("/updatestudent")
	public ResponseEntity<?> updateStudent(@RequestBody Student student){
		return new ResponseEntity<>(studentService.updateStudent(student),HttpStatus.OK);
	}
	
	@GetMapping("/viewstudent")
	public ResponseEntity<?> viewStudent(){
		return new ResponseEntity<>(studentService.viewStudent(),HttpStatus.OK);
	}
	
	@DeleteMapping("/deletestudent/{id}")
	public ResponseEntity<?> deleteStudent(@PathVariable("id")int studentId){
		return new ResponseEntity<>(studentService.deleteStudent(studentId),HttpStatus.OK);
	}
	
	@GetMapping("/microservice")
	public String dispMessage()
	{
		String baseUrl = "http://localhost:8765/message";
		String response = (String) restTemplate.exchange(baseUrl, HttpMethod.GET, null, String.class).getBody();
		return response;
	}
}
