package com.example.studentmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class StudentmicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentmicroserviceApplication.class, args);
	}

}
