package com.example.studentmicroservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.studentmicroservice.model.Student;
import com.example.studentmicroservice.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	StudentRepository studentRepository;
	
	@Override
	public Student addStudent(Student student) {
		return studentRepository.save(student);
	}

	@Override
	public Student updateStudent(Student student) {
		Student studentUpdate=studentRepository.findById(student.getId()).orElse(null);
		studentUpdate.setId(student.getId());
		studentUpdate.setName(student.getName());
		studentUpdate.setDept(student.getDept());
		studentUpdate.setEmail(student.getEmail());
		studentRepository.save(studentUpdate);
		return studentUpdate;
	}

	@Override
	public List<Student> viewStudent() {
		return studentRepository.findAll();
	}

	@Override
	public List<Student> deleteStudent(int studentId) {
		studentRepository.deleteById(studentId);
		return studentRepository.findAll();
	}

	
}
