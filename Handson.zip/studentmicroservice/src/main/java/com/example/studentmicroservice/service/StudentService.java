package com.example.studentmicroservice.service;

import java.util.List;

import com.example.studentmicroservice.model.Student;

public interface StudentService {

	public Student addStudent(Student student);
	public Student updateStudent(Student student);
	public List<Student> viewStudent();
	public List<Student> deleteStudent(int studentId);
}
