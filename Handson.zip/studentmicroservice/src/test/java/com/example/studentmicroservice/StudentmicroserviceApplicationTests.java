package com.example.studentmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
