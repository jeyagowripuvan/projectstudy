package com.example.firstmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstmicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
