package com.example.firstmicroservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MainController {
	
	@GetMapping("/message")
	public String dispMessage() {
		return "Inside another microservice";
	}
}
